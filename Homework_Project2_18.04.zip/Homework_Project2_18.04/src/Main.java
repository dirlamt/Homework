import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

            int[] arr = {5, 17, 1, 4, 8, 2, 7, 3, 14};   // исходный массив
            int n = arr.length;

            // внешний цикл для прохода по массиву
            for (int i = 0; i < n-1; i++) {

                // внутренний цикл для сравнения пар соседних элементов
                for (int j = 0; j < n-i-1; j++) {
                    if (arr[j] > arr[j+1]) {
                        // если порядок пары элементов неверен, то меняем их местами
                        int temp = arr[j];
                        arr[j] = arr[j+1];
                        arr[j+1] = temp;
                    }
                }
            }
            // выводим отсортированный массив на экран
            System.out.println(Arrays.toString(arr));
    }
}