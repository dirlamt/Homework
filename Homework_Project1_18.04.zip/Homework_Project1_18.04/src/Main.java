// 1 уровень сложности: Проект 1. Двумерные массивы
//1 Создайте двумерный массив и заполните его буквами русского алфавита.
//2* (по желанию) Пусть в двумерном массиве N элементов.
// Заполните двумерный массив целыми числами от 1 до N по спирали. Например,
//01 02 03 04
//12 13 14 05
//11 16 15 06
//10 09 08 07
public class Main {
    public static void main(String[] args) {
        int n = 33; // 33 буквы размер массива
        //однако ё не выводит
        char[][] alphabetArray = new char[3][11];
        char letter = 'А';
        for (int i = 0; i < alphabetArray.length; i++) {
            for (int j = 0; j < alphabetArray[i].length; j++) {
                alphabetArray[i][j] = letter;
                letter++;
            }
        }

        for (int i = 0; i < alphabetArray.length; i++) {
            for (int j = 0; j < alphabetArray[i].length; j++) {
                System.out.print(alphabetArray[i][j] + " ");
            }
            System.out.println();
        }

        int[][] spiralArray = new int[5][5];
        int num = 1;
        for (int i = 0; i < spiralArray.length / 2; i++) {
            for (int j = i; j < spiralArray.length - i - 1; j++) {
                spiralArray[i][j] = num++;
            }
            for (int j = i; j < spiralArray.length - i - 1; j++) {
                spiralArray[j][spiralArray.length - i - 1] = num++;
            }
            for (int j = spiralArray.length - i - 1; j > i; j--) {
                spiralArray[spiralArray.length - i - 1][j] = num++;
            }
            for (int j = spiralArray.length - i - 1; j > i; j--) {
                spiralArray[j][i] = num++;
            }
        }
        if (spiralArray.length % 2 == 1) {
            spiralArray[spiralArray.length / 2][spiralArray.length / 2] = num;
        }


        System.out.println();

        for (int i = 0; i < spiralArray.length; i++) {
            for (int j = 0; j < spiralArray[i].length; j++) {
                System.out.print(spiralArray[i][j] + " ");
            }
            System.out.println();
        }
    }
}




