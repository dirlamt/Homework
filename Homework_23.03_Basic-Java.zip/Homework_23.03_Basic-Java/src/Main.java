import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

//1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
//
//
//умножить число на 2, если оно нечётное;
//
//прибавить к числу 5, если если оно заканчивается на 5 или 0.
//Если число < 0, то взять его по модулю и разделить на 3.
//Результат вычисления вывести в консоль.
//
//
//2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9), то вывести эту цифру в консоль.
// Если строка начинается со знака _ или знака -, то вывести в консоль строку без этого знака.
// Используйте методы startsWith, charAt и substring.
//
//
//3 Пользователь вводит два числа. Если они не равны, то вывести в консоль их сумму, иначе вывести их произведение.
// Используйте тернарный оператор.
//
//
//4 С помощью Random сгенерируйте три числа. Напишите программу, которая находит максимальное из них.
// Используйте тернарные операторы.
public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);

        System.out.println("Insert a number: ");

        int n = scr.nextInt();
        if (n>0) {
            if((n%2)==0){
                n=n*2;
            }
            if((n%10)==0 || (n%5)==0)
            {
                n=n+5;
            }
        } else if (n<0) {
            n = Math.abs(n)/3;
            
        }
        System.out.println(n);
        // Project 2
        System.out.println("Insert a String: ");
        Scanner scr1 = new Scanner(System.in);
        String s = scr1.nextLine();
        if (s.startsWith("0")){
            System.out.println("0");
        }
        if (s.startsWith("1")){
            System.out.println("1");
        }
        if (s.startsWith("2")){
            System.out.println("2");
        }
        if (s.startsWith("3")){
            System.out.println("3");
        }
        if (s.startsWith("4")){
            System.out.println("4");
        }
        if (s.startsWith("5")){
            System.out.println("5");
        }
        if (s.startsWith("6")){
            System.out.println("6");
        }
        if (s.startsWith("7")){
            System.out.println("7");
        }
        if (s.startsWith("8")){
            System.out.println("8");
        }
        if (s.startsWith("9")){
            System.out.println("9");
        }
        if (s.startsWith("-") || s.startsWith("_")){
            System.out.println(s.substring(1));
        }
// Project 3

        System.out.println("Insert X:");
        int x = scr.nextInt();
        System.out.println("Insert Y:");
        int y = scr.nextInt();
        if (x==y){
            System.out.println(x+y);
        }
        else {
            System.out.println(x*y);
        }
// Project 4

         Random random = new Random();
        int n1 = random.nextInt();
        int n2 = random.nextInt();
        int n3 = random.nextInt();
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);

        if (n1>n2 && n1>n3){
            System.out.println(n1);
        }
        else{
            if(n2>n3){
                System.out.println(n2);
            }
            else {
                System.out.println(n3);

            }
        }



    }

}