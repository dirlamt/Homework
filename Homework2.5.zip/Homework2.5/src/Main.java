public class Main {
    public static void main(String[] args) {
        byte maxbyte=127;
        System.out.println(maxbyte);
        maxbyte++;
        System.out.println(maxbyte);

    }
}