public class Main {
    public static void main(String[] args) {

        System.out.println("остаток от деления 5 на 4: " + 5%4);
        System.out.println("остаток от деления 15 на 3:" + 15%3);
        boolean b1 = 2%2 == 0;
        boolean b2 = 7%2 == 0;
        boolean b3 = 13%2 == 0;
        boolean b4 = 14%2 == 0;
        System.out.println("2 число четное " + b1);
        System.out.println("7 число четное " + b2);
        System.out.println("13 число четное " + b3);
        System.out.println("14 число четное " + b4);
        int number=27;
        System.out.println("последняя цифра от 27 это " + 27%10);






    }

}