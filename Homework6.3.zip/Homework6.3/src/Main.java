//Проект 3
      //  1 Создайте строковую переменную, положите в неё "I study Basic Java!" или любое другое предложение
      //  2 Распечатайте первый символ строки. Используем метод String.charAt().
      //  3 Распечатайте последний символ строки.
      //  4 Проверить, содержит ли Ваша строка подстроку “Java”. Используем метод String.contains(). Вывести в консоль результат проверки
      //  5 Заменить все символы "а" на "о". Вывести в консоль результат
      //  6 Преобразуйте строку к верхнему регистру. Выведите в консоль
      //  7 Преобразуйте строку к нижнему регистру. Выведите в консоль
      //  8 Вырезать подстроку "Java" c помощью метода String.substring().


public class Main {
    public static void main(String[] args) {
        String s = "I study Basic Java!";
        System.out.println(s.charAt(0));
        System.out.println(s.charAt(s.length()-1));
        System.out.println(s.contains("Java"));
        System.out.println(s.replaceAll("a", "o"));
        System.out.println(s.toUpperCase());
        System.out.println(s.toLowerCase());
        s =(s.substring(0,14));







    }
}