
        import java.util.Arrays;
        import java.util.Scanner;

        public class Main {
            public static void main(String[] args) {

                Scanner scanner = new Scanner(System.in);
                System.out.print("Введите строку: ");
                String inputString = scanner.nextLine();

                char[] characters = inputString.toCharArray();
                Arrays.sort(characters);

                System.out.print("Строка в алфавитном порядке: ");
                for (char c : characters) {
                    System.out.print(c);
                }
                
    }
}