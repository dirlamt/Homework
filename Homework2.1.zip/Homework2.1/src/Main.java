public class Main {
    public static void main(String[] args) {
        boolean bool = true;
        byte by = 123;
        short sh = 13000;
        int i = 300001;
        long l = 36363636368789l;
        float f = 45.212121f;
        double d = 786.9999999999999;
        char ch = 123;
        System.out.print("boolean: ");
        System.out.println(bool);
        System.out.print("byte: ");
        System.out.println(by);
        System.out.print("short: ");
        System.out.println(sh);
        System.out.print("int: ");
        System.out.println(i);
        System.out.print("long: ");
        System.out.println(l);
        System.out.print("float: ");
        System.out.println(f);
        System.out.print("double: ");
        System.out.println(d);
        System.out.print("char: ");
        System.out.println(ch);
        System.out.print("new char: ");
        ch=125;
        System.out.println(ch);
        System.out.print("new double: ");
        d=788.111111;
        System.out.println(d);
        System.out.print("new boolean: ");
        bool=false;
        System.out.println(bool);












    }
}