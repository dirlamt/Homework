import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Input first String: ");
        String str1 = scanner.nextLine();
        System.out.println("Input second String: ");
        String str2 = scanner.nextLine();
        System.out.println("Input third String: ");
        String str3 = scanner.nextLine();
        System.out.println("Input delimiter: ");
        String delimiter = scanner.nextLine();
        String strc = combine(str1, str2, str3, delimiter);
        System.out.println(strc);
        firstChar(strc);
    }

    public static String combine(String str1, String str2, String str3, String delimiter){

        return str1 + delimiter + str2 + delimiter + str3;

    }
    public static void firstChar(String str){
        System.out.println(str.charAt(0));

    }


}