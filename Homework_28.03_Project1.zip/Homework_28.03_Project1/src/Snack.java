public enum Snack {
    SNICKERS, MARS, BOUNTY, KITKAT
}
