import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Input number of snack: ");
        int snackNumber = scr.nextInt();
        String snackName = switch (snackNumber) {
            case 1 -> Snack.SNICKERS.name();
            case 2 -> Snack.MARS.name();
            case 3 -> Snack.BOUNTY.name();
            case 4 -> Snack.KITKAT.name();
            default -> "There is no snack with this number.";
        };
        System.out.println(snackName);
    }

}