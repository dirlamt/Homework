import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Input bottom: ");
        int b = scr.nextInt();
        System.out.println("Input top : ");
        int t = scr.nextInt();
        int summa = 0;
        for (int i = b; i < t; i++) {
            if((i%2)!=0){
                summa = summa + i;
            }
        }
        System.out.println("Total: " + summa);
    }
}
