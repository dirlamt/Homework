public class Main {
    public static void main(String[] args) {


        System.out.println("Иван Иванович Иванов");
        System.out.println("Age 31");
        System.out.println("Height 178");
        System.out.println("");
        System.out.println("Отто Карлович фон Бисмарк");
        System.out.println("Age 68");
        System.out.println("Height 180");
        System.out.println("");
        System.out.println("Аркадий Гигорьевич Сидоров");
        System.out.println("Age 72");
        System.out.println("Height 195");
        System.out.println("");
        System.out.printf("%.2f, %.2f, %.2f", 3.222, 4.333, 5.444 );
        System.out.println("");
        System.out.println("");
        System.out.print("I");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.println("I");
        System.out.print("I");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.println("I");
        System.out.print("I");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.println("I");




    }
}