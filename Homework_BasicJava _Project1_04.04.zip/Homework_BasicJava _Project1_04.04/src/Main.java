import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        Random rnd = new Random();
        int sum = 0;
        while(sum < 100000) {
            int r = rnd.nextInt(1,4);
            int banknote = switch (r) {

                case 1 -> 500;
                case 2 -> 1000;
                case 3 -> 2000;
                case 4 -> 5000;
                default -> 0;

            };
            sum = sum + banknote;
            System.out.println(banknote);
        }
        System.out.println("Набраная сумма: " + sum + " Идем в Бар.");
    }
}