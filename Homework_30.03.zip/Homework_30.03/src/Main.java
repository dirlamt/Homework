import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("сколько лет вы в браке?");
        int j = scr.nextInt();
        String message = switch (j){
            case 1 ->concat(Wedding.ODIN);
            case 2 ->concat(Wedding.DWA);
            case 3 ->concat(Wedding.TRI);
            case 4 ->concat(Wedding.CHETYRE);
            case 5 ->concat(Wedding.PJAT);
            case 6 ->concat(Wedding.SHEST);
            case 7 ->concat(Wedding.SEM);
            case 8 ->concat(Wedding.WOSEM);
            case 9 ->concat(Wedding.DEWJAT);
            case 10 ->concat(Wedding.DESJAT);
            default -> "такого значения нет";
        };
        System.out.println(message);
    }
    public static String concat(Wedding wed){
        return wed.name() + " " + wed.getDescription();
    }
}