public enum Wedding {
    ODIN("Ситцевая"),
    DWA("Бумажная"),
    TRI("Кожаная"),
    CHETYRE("Льняная"),
    PJAT("Деревянная"),
    SHEST("Чугуная "),
    SEM("Медная"),
    WOSEM("Жестяная "),
    DEWJAT("Фаянсовая"),
    DESJAT("Оловянная");

    private final String description;

    public String getDescription() {
        return description;
    }

    Wedding(String description) {
        this.description = description;
    }
}
