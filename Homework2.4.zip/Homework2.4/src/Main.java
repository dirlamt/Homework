public class Main {
    public static void main(String[] args) {
        int i1=5,i2=256;
        long l1=363636363636l,l2=6475758585959l;
        double d1=4545.76766,d2=6565.463333;
        float f1=6582222199.34343434343f,f2=4646.565656564f;

        int i3=i1 + i2;
        long l3=l1 + l2;
        long l4=i1 + l1;
        float f3=i1 + f1;
        double d3=i1 + d1;
        double d4=l1 + d1;


        System.out.println(i3);
        System.out.println(l3);
        System.out.println(l4);
        System.out.println(f3);
        System.out.println(d3);
        System.out.println(d4);

    }
}