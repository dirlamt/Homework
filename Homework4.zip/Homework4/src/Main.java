import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(
            String[] args) {

        //проект 1
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите любое трехзначное число: ");
        short a = scanner.nextShort();
        System.out.println(a/100);
        System.out.println(a/10%10);
        System.out.println(a%10);

        //проект 2
        Random random = new Random();
        int b,c,d;
        b = random.nextInt(999);
        c = random.nextInt(999);
        d = random.nextInt(999);
        System.out.println("Первое сгенеририванное, случайное число: " + b);
        System.out.println("Второе сгенеририванное, случайное число: " + c);
        System.out.println("Третье сгенеририванное, случайное число: " + d);
        System.out.println("Сумма сгенерированных, случайных чисел: "+ (b+c+d));
        System.out.println("Произведение сгенерированных, случайных чисел: "+b*c*d);


    }
}