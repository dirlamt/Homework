import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Введите строку: ");
        String str = input.nextLine();
        String[] words = str.split(" ");
        int count = 0;
        for (String word : words) {
            if (word.length() > 3) {
                System.out.println(word);
            }
            count++;
        }
        System.out.println("Количество слов: " + count);
    }
}