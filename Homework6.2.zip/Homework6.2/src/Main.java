//Проект 2
//1 Создайте переменную long lo = 1000L;
//2 Присвойте её значение новым переменным типов byte, short, int, double.
//3 Выведите значение новых переменных в консоль.
public class Main {
    public static void main(String[] args) {
        long lo = 1000L;
        byte b = (byte)lo;
        short sh = (short)lo;
        int i = (int)lo;
        double d = (double)lo;
        System.out.println(b);
        System.out.println(sh);
        System.out.println(i);
        System.out.println(d);
    }
}