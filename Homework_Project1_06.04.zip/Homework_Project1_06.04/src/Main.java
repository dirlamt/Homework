import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Input n: ");
        int n = scr.nextInt();
        int houseNum[] = new int[10*n+1];
        for (int i = 0; i <=10 ; i++) {
            houseNum[n*i]=n*i;
            System.out.println(houseNum[n*i]);


        }
    }
}