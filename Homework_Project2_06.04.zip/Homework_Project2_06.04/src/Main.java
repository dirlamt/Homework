import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        Random rnd = new Random();
        System.out.println("Input n: ");
        int n = scr.nextInt();
        int[] num = new int[n];
        int biggestNum = num[0];
        for (int i = 0; i < num.length; i++) {
            num[i]= rnd.nextInt();
            if (Math.abs(num[i]) > Math.abs(biggestNum)){
                    biggestNum = Math.abs(num[i]);
            }
            System.out.println(num[i]);


        }
        System.out.println(biggestNum);

    }
}